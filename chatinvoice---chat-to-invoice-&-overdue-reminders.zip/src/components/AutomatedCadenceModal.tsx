import React, { useState } from 'react';
import {
  X,
  Zap,
  Mail,
  Send,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ChevronRight,
  ExternalLink,
  Copy,
  Settings2,
  Calendar,
} from 'lucide-react';
import { Invoice, UserSettings } from '../types/invoice';
import {
  getPendingCadenceEmails,
  PendingCadenceEmail,
  recordCadenceSent,
  CadenceStage,
} from '../utils/cadenceEngine';
import { formatCurrency, formatUSD, getTotal } from '../utils/currency';

interface AutomatedCadenceModalProps {
  invoices: Invoice[];
  settings: UserSettings;
  isOpen: boolean;
  onClose: () => void;
  onUpdateInvoice: (updated: Invoice) => void;
  onUpdateSettings: (settings: UserSettings) => void;
  onNotify: (message: string) => void;
}

export const AutomatedCadenceModal: React.FC<AutomatedCadenceModalProps> = ({
  invoices,
  settings,
  isOpen,
  onClose,
  onUpdateInvoice,
  onUpdateSettings,
  onNotify,
}) => {
  const [selectedEmail, setSelectedEmail] = useState<PendingCadenceEmail | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastDispatchedCount, setLastDispatchedCount] = useState<number | null>(null);

  if (!isOpen) return null;

  const pendingEmails = getPendingCadenceEmails(invoices, settings);
  const config = settings.cadenceConfig || {
    day3Enabled: true,
    day7Enabled: true,
    day14Enabled: true,
    autoSendEnabled: true,
  };

  const handleToggleCadence = (key: 'day3Enabled' | 'day7Enabled' | 'day14Enabled') => {
    const updated = {
      ...settings,
      cadenceConfig: {
        ...config,
        [key]: !config[key],
      },
    };
    onUpdateSettings(updated);
  };

  const handleSendSingle = (pending: PendingCadenceEmail) => {
    const updatedInvoice = recordCadenceSent(pending.invoice, pending.stage, pending.subject);
    onUpdateInvoice(updatedInvoice);
    onNotify(`Follow-up email sent to ${pending.recipientEmail} (${pending.stageLabel})`);

    // Also trigger mailto so user can send from their client if desired
    const mailto = `mailto:${encodeURIComponent(pending.recipientEmail)}?subject=${encodeURIComponent(
      pending.subject
    )}&body=${encodeURIComponent(pending.body)}`;
    window.location.href = mailto;
  };

  const handleBatchDispatchAll = () => {
    if (pendingEmails.length === 0) return;
    setIsProcessing(true);

    setTimeout(() => {
      let count = 0;
      for (const item of pendingEmails) {
        const updatedInvoice = recordCadenceSent(item.invoice, item.stage, item.subject);
        onUpdateInvoice(updatedInvoice);
        count++;
      }
      setIsProcessing(false);
      setLastDispatchedCount(count);
      onNotify(`Successfully dispatched ${count} automated overdue reminder emails!`);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/75 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                <span>Automated Overdue Reminder Cadence</span>
                <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                  3d • 7d • 14d
                </span>
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Automated multi-stage email follow-up sequence when invoices pass their due date
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cadence Rules Overview Bar */}
        <div className="p-6 bg-zinc-50/70 dark:bg-zinc-800/40 border-b border-zinc-200 dark:border-zinc-800">
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-3 flex items-center justify-between">
            <span>Configured Reminder Cadences</span>
            <span className="text-zinc-400 normal-case font-normal text-[11px]">
              Toggle stages below to customize
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Stage 1: 3 Days */}
            <div
              onClick={() => handleToggleCadence('day3Enabled')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                config.day3Enabled
                  ? 'border-emerald-500/50 bg-white dark:bg-zinc-900 shadow-xs'
                  : 'border-zinc-200 dark:border-zinc-800 opacity-60 bg-zinc-100 dark:bg-zinc-800/50'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200 mb-1">
                <span>1. Day 3 Check-In</span>
                <span className={`w-2 h-2 rounded-full ${config.day3Enabled ? 'bg-emerald-500' : 'bg-zinc-400'}`}></span>
              </div>
              <p className="text-[11px] text-zinc-500 leading-tight">
                Polite email asking if invoice was received and when payment can be expected.
              </p>
            </div>

            {/* Stage 2: 7 Days */}
            <div
              onClick={() => handleToggleCadence('day7Enabled')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                config.day7Enabled
                  ? 'border-amber-500/50 bg-white dark:bg-zinc-900 shadow-xs'
                  : 'border-zinc-200 dark:border-zinc-800 opacity-60 bg-zinc-100 dark:bg-zinc-800/50'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200 mb-1">
                <span>2. Day 7 Notice</span>
                <span className={`w-2 h-2 rounded-full ${config.day7Enabled ? 'bg-amber-500' : 'bg-zinc-400'}`}></span>
              </div>
              <p className="text-[11px] text-zinc-500 leading-tight">
                Formal follow-up reminding that invoice is 1 week overdue, includes bank details.
              </p>
            </div>

            {/* Stage 3: 14 Days */}
            <div
              onClick={() => handleToggleCadence('day14Enabled')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                config.day14Enabled
                  ? 'border-rose-500/50 bg-white dark:bg-zinc-900 shadow-xs'
                  : 'border-zinc-200 dark:border-zinc-800 opacity-60 bg-zinc-100 dark:bg-zinc-800/50'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-bold text-zinc-800 dark:text-zinc-200 mb-1">
                <span>3. Day 14 Final</span>
                <span className={`w-2 h-2 rounded-full ${config.day14Enabled ? 'bg-rose-500' : 'bg-zinc-400'}`}></span>
              </div>
              <p className="text-[11px] text-zinc-500 leading-tight">
                Urgent final warning to prevent service stoppage or escalation.
              </p>
            </div>
          </div>
        </div>

        {/* Main Body: Pending Emails Due */}
        <div className="p-6 space-y-4 max-h-[calc(85vh-260px)] overflow-y-auto">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-blue-500" />
              Invoices Ready for Automated Cadence Email ({pendingEmails.length})
            </h3>

            {pendingEmails.length > 0 && (
              <button
                type="button"
                disabled={isProcessing}
                onClick={handleBatchDispatchAll}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs flex items-center gap-1.5 transition-all disabled:opacity-50"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>
                  {isProcessing ? 'Dispatching...' : `Dispatch All (${pendingEmails.length})`}
                </span>
              </button>
            )}
          </div>

          {lastDispatchedCount !== null && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>
                Batch complete: {lastDispatchedCount} reminder email{lastDispatchedCount === 1 ? '' : 's'}{' '}
                were processed and recorded in the client history logs.
              </span>
            </div>
          )}

          {pendingEmails.length > 0 ? (
            <div className="space-y-3">
              {pendingEmails.map((item) => {
                const total = getTotal(item.invoice);
                const isSelected = selectedEmail?.invoice.id === item.invoice.id;

                return (
                  <div
                    key={`${item.invoice.id}-${item.stage}`}
                    className="p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-xs space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                            {item.invoice.client}
                          </span>
                          <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                            {item.invoice.id}
                          </span>
                          <span
                            className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                              item.stage === '14d'
                                ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                                : item.stage === '7d'
                                ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                            }`}
                          >
                            {item.stageLabel} ({item.daysLate}d late)
                          </span>
                        </div>
                        <div className="text-xs text-zinc-500 flex items-center gap-2">
                          <span>Recipient: {item.recipientEmail}</span>
                          <span>•</span>
                          <span>Due: {item.invoice.due}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="text-right mr-2">
                          <div className="font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                            {formatCurrency(total, item.invoice.currency)}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => setSelectedEmail(isSelected ? null : item)}
                          className="px-3 py-1.5 rounded-xl text-xs font-medium border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300"
                        >
                          {isSelected ? 'Hide Preview' : 'Preview Email'}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleSendSingle(item)}
                          className="px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1 shadow-xs"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Send Email</span>
                        </button>
                      </div>
                    </div>

                    {/* Email Preview Drawer if expanded */}
                    {isSelected && (
                      <div className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700/60 space-y-2 text-xs">
                        <div className="font-mono text-zinc-800 dark:text-zinc-200">
                          <strong>Subject:</strong> {item.subject}
                        </div>
                        <div className="p-3 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 font-mono text-[11px] whitespace-pre-line text-zinc-700 dark:text-zinc-300 max-h-48 overflow-y-auto">
                          {item.body}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center bg-zinc-50 dark:bg-zinc-800/40 rounded-2xl border border-zinc-200 dark:border-zinc-800">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <h4 className="text-sm font-bold text-zinc-800 dark:text-zinc-200">
                All Overdue Cadences are Up to Date!
              </h4>
              <p className="text-xs text-zinc-500 max-w-sm mx-auto mt-1">
                There are currently no overdue invoices awaiting 3-day, 7-day, or 14-day automated emails. Any future overdue milestones will appear here automatically.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 flex items-center justify-between text-xs">
          <span className="text-zinc-500">
            Cadence emails include bank transfer & PayPal details automatically.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 font-semibold rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
