import React, { useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Percent,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Bell,
  Eye,
  FileText,
} from 'lucide-react';
import { Invoice, InvoiceStatus, UserSettings } from '../types/invoice';
import {
  formatCurrency,
  formatUSD,
  formatNGN,
  getDaysLate,
  getEffectiveStatus,
  getTotal,
} from '../utils/currency';

interface DashboardProps {
  invoices: Invoice[];
  settings: UserSettings;
  onOpenReminder: (invoice: Invoice) => void;
  onViewDetails: (invoice: Invoice) => void;
  onStatusChange: (invoice: Invoice, newStatus: InvoiceStatus) => void;
  onNewInvoice: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  invoices,
  settings,
  onOpenReminder,
  onViewDetails,
  onStatusChange,
  onNewInvoice,
}) => {
  // Currency display mode (USD or NGN)
  const [currencyMode, setCurrencyMode] = useState<'USD' | 'NGN'>('USD');
  // Bar chart metric view: 'amount' | 'count'
  const [barMetric, setBarMetric] = useState<'amount' | 'count'>('amount');

  // Determine current month key YYYY-MM
  const currentMonthKey = useMemo(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }, []);

  const currentMonthLabel = useMemo(() => {
    const [y, m] = currentMonthKey.split('-');
    const date = new Date(Number(y), Number(m) - 1, 1);
    return date.toLocaleString('default', { month: 'long', year: 'numeric' });
  }, [currentMonthKey]);

  // Convert USD to display currency
  const toDisplay = (amountUSD: number) => {
    if (currencyMode === 'NGN') {
      return amountUSD * (settings.exchangeRateNGN || 1580);
    }
    return amountUSD;
  };

  const formatDisplay = (amountUSD: number) => {
    if (currencyMode === 'NGN') {
      return formatNGN(toDisplay(amountUSD));
    }
    return formatUSD(amountUSD);
  };

  // 1. Compute Monthly Revenue Growth Data (Last 6 Months)
  const monthlyRevenueData = useMemo(() => {
    const monthMap: Record<
      string,
      {
        monthKey: string;
        label: string;
        paidRevenueUSD: number;
        totalBilledUSD: number;
        paidCount: number;
        totalCount: number;
      }
    > = {};

    // Generate past 6 months slots so there are no empty gaps
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const label = d.toLocaleString('default', { month: 'short', year: '2-digit' });
      monthMap[key] = {
        monthKey: key,
        label,
        paidRevenueUSD: 0,
        totalBilledUSD: 0,
        paidCount: 0,
        totalCount: 0,
      };
    }

    // Populate data from invoices
    for (const inv of invoices) {
      const usdVal = inv.totalUSD || getTotal(inv) / (inv.rate || settings.exchangeRateNGN);

      // Determine relevant month: use paidDate month if paid, else due date or created date
      let monthKey = (inv.paidDate || inv.due || inv.created || '').slice(0, 7);
      if (!monthKey || !monthMap[monthKey]) {
        // If outside the 6 months window or missing, skip from the 6-month chart
        // Check if created in range
        const fallbackKey = (inv.due || inv.created || '').slice(0, 7);
        if (monthMap[fallbackKey]) {
          monthKey = fallbackKey;
        } else {
          continue;
        }
      }

      if (monthMap[monthKey]) {
        monthMap[monthKey].totalBilledUSD += usdVal;
        monthMap[monthKey].totalCount += 1;

        if (inv.status === 'Paid') {
          monthMap[monthKey].paidRevenueUSD += usdVal;
          monthMap[monthKey].paidCount += 1;
        }
      }
    }

    // Convert to sorted array and calculate growth rates
    const list = Object.values(monthMap).sort((a, b) => a.monthKey.localeCompare(b.monthKey));

    return list.map((item, index) => {
      let growthRate = 0;
      if (index > 0) {
        const prevPaid = list[index - 1].paidRevenueUSD;
        if (prevPaid > 0) {
          growthRate = Number((((item.paidRevenueUSD - prevPaid) / prevPaid) * 100).toFixed(1));
        } else if (item.paidRevenueUSD > 0) {
          growthRate = 100;
        }
      }

      return {
        ...item,
        displayPaidRevenue: Number(toDisplay(item.paidRevenueUSD).toFixed(2)),
        displayTotalBilled: Number(toDisplay(item.totalBilledUSD).toFixed(2)),
        growthRate,
      };
    });
  }, [invoices, settings.exchangeRateNGN, currencyMode]);

  // Overall MoM growth calculation for current month
  const currentMonthGrowth = useMemo(() => {
    if (monthlyRevenueData.length < 2) return 0;
    const current = monthlyRevenueData[monthlyRevenueData.length - 1];
    return current.growthRate;
  }, [monthlyRevenueData]);

  // 2. Compute Current Month Paid vs Overdue Ratio Data
  const currentMonthStats = useMemo(() => {
    let paidAmountUSD = 0;
    let overdueAmountUSD = 0;
    let pendingUpcomingUSD = 0;

    let paidCount = 0;
    let overdueCount = 0;
    let pendingCount = 0;

    const currentMonthInvoices: Invoice[] = [];

    for (const inv of invoices) {
      const invMonth = (inv.due || inv.paidDate || inv.created || '').slice(0, 7);
      const isCurrentMonth = invMonth === currentMonthKey;

      const eff = getEffectiveStatus(inv);
      const usdVal = inv.totalUSD || getTotal(inv) / (inv.rate || settings.exchangeRateNGN);

      if (isCurrentMonth || eff === 'Overdue') {
        currentMonthInvoices.push(inv);
      }

      if (isCurrentMonth) {
        if (eff === 'Paid') {
          paidAmountUSD += usdVal;
          paidCount += 1;
        } else if (eff === 'Overdue') {
          overdueAmountUSD += usdVal;
          overdueCount += 1;
        } else if (eff === 'Sent') {
          pendingUpcomingUSD += usdVal;
          pendingCount += 1;
        }
      } else if (eff === 'Overdue') {
        // Also account for prior overdue debt that remains active
        overdueAmountUSD += usdVal;
        overdueCount += 1;
      }
    }

    const totalActive = paidAmountUSD + overdueAmountUSD;
    const paidPercentage = totalActive > 0 ? (paidAmountUSD / totalActive) * 100 : 0;
    const overduePercentage = totalActive > 0 ? (overdueAmountUSD / totalActive) * 100 : 0;

    // Paid-to-Overdue Ratio string
    let ratioString = 'N/A';
    if (overdueAmountUSD === 0 && paidAmountUSD > 0) {
      ratioString = '100% Paid (No Overdue)';
    } else if (paidAmountUSD === 0 && overdueAmountUSD > 0) {
      ratioString = '0 : 1 (100% Overdue)';
    } else if (overdueAmountUSD > 0) {
      const r = (paidAmountUSD / overdueAmountUSD).toFixed(1);
      ratioString = `${r} : 1`;
    }

    return {
      paidAmountUSD,
      overdueAmountUSD,
      pendingUpcomingUSD,
      paidCount,
      overdueCount,
      pendingCount,
      totalActive,
      paidPercentage: Number(paidPercentage.toFixed(1)),
      overduePercentage: Number(overduePercentage.toFixed(1)),
      ratioString,
      invoices: currentMonthInvoices,
    };
  }, [invoices, currentMonthKey, settings.exchangeRateNGN]);

  // Bar chart dataset comparing Paid vs Overdue for Current Month
  const barChartData = useMemo(() => {
    return [
      {
        category: 'Paid Invoices',
        amountUSD: currentMonthStats.paidAmountUSD,
        displayAmount: Number(toDisplay(currentMonthStats.paidAmountUSD).toFixed(2)),
        count: currentMonthStats.paidCount,
        color: '#10b981', // emerald
        percentage: currentMonthStats.paidPercentage,
      },
      {
        category: 'Overdue Invoices',
        amountUSD: currentMonthStats.overdueAmountUSD,
        displayAmount: Number(toDisplay(currentMonthStats.overdueAmountUSD).toFixed(2)),
        count: currentMonthStats.overdueCount,
        color: '#f43f5e', // rose
        percentage: currentMonthStats.overduePercentage,
      },
    ];
  }, [currentMonthStats, currencyMode, settings.exchangeRateNGN]);

  return (
    <div className="space-y-6">
      {/* Dashboard Top Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-zinc-900 dark:text-zinc-100">
              Revenue & Performance Dashboard
            </h1>
          </div>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
            Tracking revenue trajectory and monitoring collection ratios for {currentMonthLabel}.
          </p>
        </div>

        {/* Currency Switcher & Add Invoice */}
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-xl p-1 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setCurrencyMode('USD')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                currencyMode === 'USD'
                  ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
              }`}
            >
              $ USD
            </button>
            <button
              type="button"
              onClick={() => setCurrencyMode('NGN')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                currencyMode === 'NGN'
                  ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
              }`}
            >
              ₦ NGN
            </button>
          </div>

          <button
            type="button"
            onClick={onNewInvoice}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all flex items-center gap-1.5"
          >
            + New Invoice
          </button>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Current Month Collected */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-zinc-500 uppercase tracking-wider font-semibold">
            <span>Collected ({currentMonthLabel.slice(0, 3)})</span>
            <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {formatDisplay(currentMonthStats.paidAmountUSD)}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            {currentMonthStats.paidCount} paid invoice{currentMonthStats.paidCount === 1 ? '' : 's'}
          </div>
        </div>

        {/* Current Month Overdue Debt */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-zinc-500 uppercase tracking-wider font-semibold">
            <span>Overdue Amount</span>
            <span className="p-1.5 rounded-lg bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold text-rose-600 dark:text-rose-400">
            {formatDisplay(currentMonthStats.overdueAmountUSD)}
          </div>
          <div className="mt-1 text-xs text-rose-500 flex items-center gap-1">
            <span>{currentMonthStats.overdueCount} accounts past due</span>
          </div>
        </div>

        {/* Paid vs Overdue Ratio Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-zinc-500 uppercase tracking-wider font-semibold">
            <span>Paid vs Overdue Ratio</span>
            <span className="p-1.5 rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400">
              <Percent className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold text-zinc-900 dark:text-zinc-100">
            {currentMonthStats.ratioString}
          </div>
          <div className="mt-1 text-xs text-zinc-500">
            <span className="text-emerald-600 font-semibold">
              {currentMonthStats.paidPercentage}%
            </span>{' '}
            settled vs{' '}
            <span className="text-rose-600 font-semibold">
              {currentMonthStats.overduePercentage}%
            </span>{' '}
            late
          </div>
        </div>

        {/* Revenue Growth (MoM) */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-zinc-500 uppercase tracking-wider font-semibold">
            <span>MoM Revenue Growth</span>
            <span
              className={`p-1.5 rounded-lg ${
                currentMonthGrowth >= 0
                  ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400'
                  : 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400'
              }`}
            >
              {currentMonthGrowth >= 0 ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
            </span>
          </div>
          <div
            className={`mt-2 text-2xl font-bold ${
              currentMonthGrowth >= 0
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {currentMonthGrowth >= 0 ? `+${currentMonthGrowth}%` : `${currentMonthGrowth}%`}
          </div>
          <div className="mt-1 text-xs text-zinc-500">vs. previous month</div>
        </div>
      </div>

      {/* Main Charts Grid: Line Chart on Left, Bar Chart on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 1. Monthly Revenue Growth (Line Chart) */}
        <div className="lg:col-span-7 p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                <span>Monthly Revenue Growth</span>
                <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400">
                  Last 6 Months
                </span>
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Visualizing collected revenue growth progression over recent months
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 font-medium text-emerald-600 dark:text-emerald-400">
                <span className="w-3 h-1 rounded-full bg-emerald-500"></span>
                Paid Revenue
              </span>
              <span className="flex items-center gap-1.5 font-medium text-zinc-400">
                <span className="w-3 h-1 rounded-full bg-zinc-300 dark:bg-zinc-600"></span>
                Total Invoiced
              </span>
            </div>
          </div>

          {/* Recharts Line Chart Container */}
          <div className="w-full h-72 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={monthlyRevenueData}
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#88888820" vertical={false} />
                <XAxis
                  dataKey="label"
                  stroke="#888888"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#88888830' }}
                />
                <YAxis
                  stroke="#888888"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#88888830' }}
                  tickFormatter={(val) =>
                    currencyMode === 'NGN' ? `₦${(val / 1000).toFixed(0)}k` : `$${val}`
                  }
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderRadius: '12px',
                    borderColor: '#27272a',
                    color: '#f4f4f5',
                    fontSize: '12px',
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)',
                  }}
                  formatter={(val: any, name: any) => {
                    const formatted =
                      currencyMode === 'NGN' ? formatNGN(val) : formatUSD(val);
                    return [
                      formatted,
                      name === 'displayPaidRevenue' ? 'Paid Revenue' : 'Total Invoiced',
                    ];
                  }}
                  labelFormatter={(lbl) => `Month: ${lbl}`}
                />
                {/* Total Invoiced Line (subtle baseline) */}
                <Line
                  type="monotone"
                  dataKey="displayTotalBilled"
                  stroke="#71717a"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={false}
                  activeDot={{ r: 4, stroke: '#71717a' }}
                />
                {/* Paid Revenue Growth Line (primary highlight) */}
                <Line
                  type="monotone"
                  dataKey="displayPaidRevenue"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#10b981', strokeWidth: 2, stroke: '#ffffff' }}
                  activeDot={{ r: 6, fill: '#10b981', stroke: '#ffffff', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
            <span>
              Cumulative Trend:{' '}
              <strong className="text-zinc-800 dark:text-zinc-200">
                {formatDisplay(
                  monthlyRevenueData.reduce((s, i) => s + i.paidRevenueUSD, 0)
                )}{' '}
                collected
              </strong>{' '}
              across 6 months
            </span>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
              MoM Trend: {currentMonthGrowth >= 0 ? `+${currentMonthGrowth}%` : `${currentMonthGrowth}%`}
            </span>
          </div>
        </div>

        {/* 2. Paid vs Overdue Invoices Ratio (Bar Chart) */}
        <div className="lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100">
                Paid vs. Overdue Ratio
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Current month ({currentMonthLabel}) collection health
              </p>
            </div>

            {/* Toggle metric: Amount vs Count */}
            <div className="flex items-center rounded-xl p-1 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-[11px] font-semibold">
              <button
                type="button"
                onClick={() => setBarMetric('amount')}
                className={`px-2 py-0.5 rounded-lg transition-colors ${
                  barMetric === 'amount'
                    ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs'
                    : 'text-zinc-500'
                }`}
              >
                Amount
              </button>
              <button
                type="button"
                onClick={() => setBarMetric('count')}
                className={`px-2 py-0.5 rounded-lg transition-colors ${
                  barMetric === 'count'
                    ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs'
                    : 'text-zinc-500'
                }`}
              >
                Count (#)
              </button>
            </div>
          </div>

          {/* Visual Ratio Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Paid: {currentMonthStats.paidPercentage}%
              </span>
              <span className="text-rose-600 dark:text-rose-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Overdue: {currentMonthStats.overduePercentage}%
              </span>
            </div>
            <div className="w-full h-3 rounded-full bg-zinc-100 dark:bg-zinc-800 overflow-hidden flex">
              <div
                style={{ width: `${currentMonthStats.paidPercentage}%` }}
                className="h-full bg-emerald-500 transition-all duration-500"
                title={`Paid: ${currentMonthStats.paidPercentage}%`}
              ></div>
              <div
                style={{ width: `${currentMonthStats.overduePercentage}%` }}
                className="h-full bg-rose-500 transition-all duration-500"
                title={`Overdue: ${currentMonthStats.overduePercentage}%`}
              ></div>
            </div>
          </div>

          {/* Recharts Bar Chart */}
          <div className="w-full h-56 pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={barChartData}
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#88888820" vertical={false} />
                <XAxis
                  dataKey="category"
                  stroke="#888888"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#88888830' }}
                />
                <YAxis
                  stroke="#888888"
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#88888830' }}
                  tickFormatter={(val) =>
                    barMetric === 'amount'
                      ? currencyMode === 'NGN'
                        ? `₦${(val / 1000).toFixed(0)}k`
                        : `$${val}`
                      : `${val}`
                  }
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderRadius: '12px',
                    borderColor: '#27272a',
                    color: '#f4f4f5',
                    fontSize: '12px',
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)',
                  }}
                  formatter={(val: any) => {
                    if (barMetric === 'amount') {
                      return [
                        currencyMode === 'NGN' ? formatNGN(val) : formatUSD(val),
                        'Volume',
                      ];
                    }
                    return [`${val} invoices`, 'Count'];
                  }}
                />
                <Bar
                  dataKey={barMetric === 'amount' ? 'displayAmount' : 'count'}
                  radius={[8, 8, 0, 0]}
                  barSize={48}
                >
                  {barChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Ratio Summary Footer */}
          <div className="p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-200/80 dark:border-zinc-700/60 text-xs flex items-center justify-between">
            <span className="text-zinc-500">Efficiency Ratio:</span>
            <span className="font-bold text-zinc-900 dark:text-zinc-100 font-mono">
              {currentMonthStats.ratioString}
            </span>
          </div>
        </div>
      </div>

      {/* Current Month Active Invoices Quick Review Table */}
      <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100">
              Current Month Invoices Breakdown ({currentMonthStats.invoices.length})
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Immediate inspection of paid and overdue accounts for {currentMonthLabel}
            </p>
          </div>
          <span className="text-xs text-zinc-400">
            Click any client to inspect details & toggle status
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-zinc-100 dark:border-zinc-800 text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                <th className="py-2.5 px-3">Client</th>
                <th className="py-2.5 px-3">Amount</th>
                <th className="py-2.5 px-3">Due Date</th>
                <th className="py-2.5 px-3">Current Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {currentMonthStats.invoices.map((inv) => {
                const eff = getEffectiveStatus(inv);
                const daysLate = getDaysLate(inv);
                const total = getTotal(inv);
                const isPaid = inv.status === 'Paid';

                return (
                  <tr
                    key={inv.id}
                    className="hover:bg-zinc-50/60 dark:hover:bg-zinc-800/40 transition-colors"
                  >
                    <td className="py-3 px-3">
                      <button
                        type="button"
                        onClick={() => onViewDetails(inv)}
                        className="font-semibold text-zinc-900 dark:text-zinc-100 hover:text-emerald-600 dark:hover:text-emerald-400 text-left transition-colors"
                      >
                        {inv.client}
                      </button>
                      <div className="text-[11px] font-mono text-zinc-400">{inv.id}</div>
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <div className="font-bold text-zinc-900 dark:text-zinc-100">
                        {formatCurrency(total, inv.currency)}
                      </div>
                      {inv.currency === 'NGN' && (
                        <div className="text-[11px] text-zinc-500">
                          ≈ {formatUSD(inv.totalUSD || total / inv.rate)}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <div className="text-zinc-700 dark:text-zinc-300 font-medium">{inv.due}</div>
                      {eff === 'Overdue' && (
                        <span className="text-[11px] text-rose-600 dark:text-rose-400 font-semibold">
                          {daysLate}d overdue
                        </span>
                      )}
                      {eff === 'Paid' && inv.paidDate && (
                        <span className="text-[11px] text-emerald-600">
                          Paid {inv.paidDate}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                          eff === 'Paid'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300'
                            : eff === 'Overdue'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-300'
                            : 'bg-blue-100 text-blue-700 dark:bg-blue-950/80 dark:text-blue-300'
                        }`}
                      >
                        {eff === 'Paid' ? (
                          <CheckCircle2 className="w-3 h-3" />
                        ) : eff === 'Overdue' ? (
                          <AlertTriangle className="w-3 h-3" />
                        ) : (
                          <Clock className="w-3 h-3" />
                        )}
                        <span>{eff}</span>
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onViewDetails(inv)}
                          title="View Details & Toggle Status"
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {eff === 'Overdue' && (
                          <button
                            type="button"
                            onClick={() => onOpenReminder(inv)}
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white flex items-center gap-1 shadow-xs"
                          >
                            <Bell className="w-3 h-3" />
                            <span>Remind</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onStatusChange(inv, isPaid ? 'Sent' : 'Paid')}
                          className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${
                            isPaid
                              ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                          }`}
                        >
                          {isPaid ? 'Mark Unpaid' : 'Mark Paid'}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
