import React, { useState, useRef, useEffect } from 'react';
import { Check, Undo2, ChevronDown, Clock, AlertTriangle, FileText } from 'lucide-react';
import { Invoice, InvoiceStatus } from '../types/invoice';
import { getEffectiveStatus } from '../utils/currency';

interface StatusButtonProps {
  invoice: Invoice;
  onStatusChange: (invoice: Invoice, newStatus: InvoiceStatus) => void;
  size?: 'sm' | 'md';
}

export const StatusButton: React.FC<StatusButtonProps> = ({
  invoice,
  onStatusChange,
  size = 'sm',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const effectiveStatus = getEffectiveStatus(invoice);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleQuickToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (invoice.status === 'Paid') {
      // Mistakenly marked as paid? Revert to Unpaid (Sent)!
      onStatusChange(invoice, 'Sent');
    } else if (invoice.status === 'Sent') {
      // Mark as Paid
      onStatusChange(invoice, 'Paid');
    } else {
      // Draft -> Sent
      onStatusChange(invoice, 'Sent');
    }
  };

  const handleSelectStatus = (newStatus: InvoiceStatus, e: React.MouseEvent) => {
    e.stopPropagation();
    setIsOpen(false);
    if (invoice.status !== newStatus) {
      onStatusChange(invoice, newStatus);
    }
  };

  const isSmall = size === 'sm';

  return (
    <div className="relative inline-flex items-center" ref={dropdownRef}>
      <div className="inline-flex rounded-lg border shadow-xs overflow-hidden transition-all bg-white dark:bg-zinc-800">
        {/* Primary Action Button */}
        {invoice.status === 'Paid' ? (
          <button
            type="button"
            onClick={handleQuickToggle}
            title="Click to revert to Unpaid if marked as paid by mistake"
            className={`group inline-flex items-center gap-1.5 font-medium transition-colors text-amber-700 bg-amber-50 hover:bg-amber-100 border-r border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800 dark:hover:bg-amber-900/50 ${
              isSmall ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-sm'
            }`}
          >
            <Undo2 className="w-3.5 h-3.5 transition-transform group-hover:-rotate-45 text-amber-600 dark:text-amber-400" />
            <span>Mark Unpaid</span>
          </button>
        ) : invoice.status === 'Sent' ? (
          <button
            type="button"
            onClick={handleQuickToggle}
            title="Click to mark this invoice as Paid"
            className={`inline-flex items-center gap-1.5 font-medium transition-colors text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border-r border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800 dark:hover:bg-emerald-900/50 ${
              isSmall ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-sm'
            }`}
          >
            <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Mark Paid</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={handleQuickToggle}
            title="Click to mark draft as Sent / Unpaid"
            className={`inline-flex items-center gap-1.5 font-medium transition-colors text-blue-700 bg-blue-50 hover:bg-blue-100 border-r border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800 dark:hover:bg-blue-900/50 ${
              isSmall ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-sm'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Mark Sent</span>
          </button>
        )}

        {/* Dropdown chevron to explicitly select any status */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsOpen(!isOpen);
          }}
          title="Change invoice status (Paid, Unpaid, Draft)"
          className={`px-1.5 flex items-center justify-center transition-colors hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 ${
            invoice.status === 'Paid'
              ? 'bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40'
              : invoice.status === 'Sent'
              ? 'bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40'
              : 'bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40'
          }`}
          aria-expanded={isOpen}
          aria-haspopup="true"
        >
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 top-full mt-1.5 w-52 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xl z-50 py-1.5 text-xs animate-in fade-in zoom-in-95">
          <div className="px-3 py-1.5 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider border-b border-zinc-100 dark:border-zinc-800">
            Edit Invoice Status
          </div>

          {/* Paid option */}
          <button
            type="button"
            onClick={(e) => handleSelectStatus('Paid', e)}
            className={`w-full px-3 py-2 text-left flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors ${
              invoice.status === 'Paid' ? 'font-semibold text-emerald-600 dark:text-emerald-400' : 'text-zinc-700 dark:text-zinc-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Paid (Payment received)</span>
            </div>
            {invoice.status === 'Paid' && <Check className="w-3.5 h-3.5 text-emerald-600" />}
          </button>

          {/* Unpaid / Sent option */}
          <button
            type="button"
            onClick={(e) => handleSelectStatus('Sent', e)}
            className={`w-full px-3 py-2 text-left flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors ${
              invoice.status === 'Sent' ? 'font-semibold text-amber-600 dark:text-amber-400' : 'text-zinc-700 dark:text-zinc-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${effectiveStatus === 'Overdue' ? 'bg-rose-500' : 'bg-blue-500'}`}></span>
              <span>
                Unpaid / Sent
                {effectiveStatus === 'Overdue' && (
                  <span className="ml-1 text-[10px] text-rose-500 font-normal">(Overdue)</span>
                )}
              </span>
            </div>
            {invoice.status === 'Sent' && <Check className="w-3.5 h-3.5 text-amber-600" />}
          </button>

          {/* Draft option */}
          <button
            type="button"
            onClick={(e) => handleSelectStatus('Draft', e)}
            className={`w-full px-3 py-2 text-left flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors ${
              invoice.status === 'Draft' ? 'font-semibold text-zinc-800 dark:text-zinc-100' : 'text-zinc-700 dark:text-zinc-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-zinc-400"></span>
              <span>Draft (Not sent yet)</span>
            </div>
            {invoice.status === 'Draft' && <Check className="w-3.5 h-3.5 text-zinc-600" />}
          </button>

          <div className="mt-1 pt-1.5 border-t border-zinc-100 dark:border-zinc-800 px-3 py-1 text-[10px] text-zinc-400 leading-tight">
            Accidentally marked paid? Select "Unpaid / Sent" above to restore it.
          </div>
        </div>
      )}
    </div>
  );
};
