import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Bell,
  Edit2,
  Trash2,
  Plus,
  Send,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Mail,
  Phone,
  MessageCircle,
  ExternalLink,
  Eye,
  Download,
} from 'lucide-react';
import { Invoice, InvoiceStatus, UserSettings } from '../types/invoice';
import {
  formatCurrency,
  formatUSD,
  getDaysLate,
  getEffectiveStatus,
  getTotal,
} from '../utils/currency';
import { exportInvoicesToCSV } from '../utils/export';
import { StatusButton } from './StatusButton';

interface InvoiceListProps {
  invoices: Invoice[];
  settings: UserSettings;
  onOpenReminder: (invoice: Invoice) => void;
  onViewDetails: (invoice: Invoice) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (invoiceId: string) => void;
  onStatusChange: (invoice: Invoice, newStatus: InvoiceStatus) => void;
  onNewInvoice: () => void;
  onResetData: () => void;
}

export type StatusFilter = 'all' | 'overdue' | 'sent' | 'paid' | 'draft';
export type SortField = 'due' | 'amount' | 'client' | 'created';

export const InvoiceList: React.FC<InvoiceListProps> = ({
  invoices,
  settings,
  onOpenReminder,
  onViewDetails,
  onEditInvoice,
  onDeleteInvoice,
  onStatusChange,
  onNewInvoice,
  onResetData,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortField, setSortField] = useState<SortField>('due');
  const [sortAsc, setSortAsc] = useState(true);

  // Financial metrics
  const metrics = useMemo(() => {
    let totalOutstandingUSD = 0;
    let totalOverdueUSD = 0;
    let totalPaidUSD = 0;
    let overdueCount = 0;
    let unpaidCount = 0;

    for (const inv of invoices) {
      const eff = getEffectiveStatus(inv);
      const usd = inv.totalUSD || getTotal(inv) / (inv.rate || settings.exchangeRateNGN);

      if (eff === 'Paid') {
        totalPaidUSD += usd;
      } else if (eff === 'Overdue') {
        totalOverdueUSD += usd;
        totalOutstandingUSD += usd;
        overdueCount++;
        unpaidCount++;
      } else if (eff === 'Sent') {
        totalOutstandingUSD += usd;
        unpaidCount++;
      }
    }

    return {
      totalOutstandingUSD,
      totalOverdueUSD,
      totalPaidUSD,
      overdueCount,
      unpaidCount,
      totalCount: invoices.length,
    };
  }, [invoices, settings.exchangeRateNGN]);

  // Filtered & sorted invoices
  const filteredInvoices = useMemo(() => {
    return invoices
      .filter((inv) => {
        const eff = getEffectiveStatus(inv);

        // Filter by tab
        if (statusFilter === 'overdue' && eff !== 'Overdue') return false;
        if (statusFilter === 'sent' && eff !== 'Sent') return false;
        if (statusFilter === 'paid' && eff !== 'Paid') return false;
        if (statusFilter === 'draft' && eff !== 'Draft') return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesClient = inv.client.toLowerCase().includes(q);
          const matchesId = inv.id.toLowerCase().includes(q);
          const matchesEmail = (inv.email || '').toLowerCase().includes(q);
          const matchesItems = inv.items.some((it) => it.desc.toLowerCase().includes(q));
          if (!matchesClient && !matchesId && !matchesEmail && !matchesItems) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        let diff = 0;
        if (sortField === 'due') {
          diff = new Date(a.due).getTime() - new Date(b.due).getTime();
        } else if (sortField === 'amount') {
          diff = (a.totalUSD || 0) - (b.totalUSD || 0);
        } else if (sortField === 'client') {
          diff = a.client.localeCompare(b.client);
        } else if (sortField === 'created') {
          diff = new Date(a.created).getTime() - new Date(b.created).getTime();
        }
        return sortAsc ? diff : -diff;
      });
  }, [invoices, statusFilter, searchQuery, sortField, sortAsc]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Outstanding Unpaid */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
              Outstanding Unpaid
            </span>
            <span className="p-2 rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold text-zinc-900 dark:text-zinc-100">
            {formatUSD(metrics.totalOutstandingUSD)}
          </div>
          <div className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
            {metrics.unpaidCount} invoice{metrics.unpaidCount === 1 ? '' : 's'} pending payment
          </div>
        </div>

        {/* Overdue Debt */}
        <div
          onClick={() => setStatusFilter('overdue')}
          className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-rose-200 dark:border-rose-900/60 shadow-xs cursor-pointer hover:border-rose-300 transition-colors"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-600 dark:text-rose-400">
              Overdue Amount
            </span>
            <span className="p-2 rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold text-rose-600 dark:text-rose-400">
            {formatUSD(metrics.totalOverdueUSD)}
          </div>
          <div className="mt-1 text-xs text-rose-500 flex items-center justify-between">
            <span>{metrics.overdueCount} accounts past due</span>
            <span className="font-semibold underline">Send reminders &rarr;</span>
          </div>
        </div>

        {/* Paid / Collected */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
              Total Paid
            </span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400">
              <CheckCircle className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {formatUSD(metrics.totalPaidUSD)}
          </div>
          <div className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
            Received into account
          </div>
        </div>

        {/* Total Invoices Count */}
        <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                Total Invoices
              </span>
              <span className="p-2 rounded-xl bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">
                <FileText className="w-4 h-4" />
              </span>
            </div>
            <div className="mt-2 text-2xl font-bold text-zinc-900 dark:text-zinc-100">
              {metrics.totalCount}
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between text-xs">
            <button
              onClick={onNewInvoice}
              className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 font-semibold"
            >
              + Create from Chat
            </button>
            <button
              onClick={onResetData}
              className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
              title="Reset to default sample invoices"
            >
              Reset Samples
            </button>
          </div>
        </div>
      </div>

      {/* Control Bar: Filters, Search, Sort */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-xs">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
              statusFilter === 'all'
                ? 'bg-zinc-900 text-white dark:bg-white dark:text-zinc-900'
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            All ({invoices.length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('overdue')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 flex items-center gap-1.5 ${
              statusFilter === 'overdue'
                ? 'bg-rose-600 text-white'
                : 'text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
            }`}
          >
            <span>Overdue</span>
            {metrics.overdueCount > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] rounded-full bg-rose-200 text-rose-800 dark:bg-rose-900 dark:text-rose-100">
                {metrics.overdueCount}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('sent')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
              statusFilter === 'sent'
                ? 'bg-blue-600 text-white'
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            Unpaid / Sent
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('paid')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
              statusFilter === 'paid'
                ? 'bg-emerald-600 text-white'
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            Paid
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('draft')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
              statusFilter === 'draft'
                ? 'bg-zinc-600 text-white'
                : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            Drafts
          </button>
        </div>

        {/* Search & Sorting */}
        <div className="flex items-center gap-2">
          {/* Search box */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search client, invoice #..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 focus:outline-emerald-500"
            />
          </div>

          {/* Sort Selector */}
          <button
            type="button"
            onClick={() => setSortAsc(!sortAsc)}
            title={`Sort ${sortAsc ? 'Ascending' : 'Descending'}`}
            className="p-1.5 rounded-xl border border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <ArrowUpDown className="w-4 h-4" />
          </button>

          {/* Export to CSV Button */}
          <button
            type="button"
            onClick={() => exportInvoicesToCSV(invoices)}
            title="Download all invoices as CSV"
            className="px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>
        </div>
      </div>

      {/* Invoices List / Table */}
      <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs overflow-hidden">
        {filteredInvoices.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-zinc-100 dark:border-zinc-800 bg-zinc-50/70 dark:bg-zinc-900/50 text-[11px] font-bold uppercase tracking-wider text-zinc-400">
                  <th className="py-3 px-4">Client & Details</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Due Date</th>
                  <th className="py-3 px-4">
                    <span className="flex items-center gap-1">
                      Status & Quick Action
                      <span className="text-[10px] text-zinc-400 lowercase font-normal">
                        (editable)
                      </span>
                    </span>
                  </th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800 text-xs">
                {filteredInvoices.map((inv) => {
                  const eff = getEffectiveStatus(inv);
                  const daysLate = getDaysLate(inv);
                  const total = getTotal(inv);
                  const reminderCount = inv.reminders ? inv.reminders.length : 0;

                  return (
                    <tr
                      key={inv.id}
                      className="hover:bg-zinc-50/60 dark:hover:bg-zinc-800/40 transition-colors"
                    >
                      {/* Client column */}
                      <td className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => onViewDetails(inv)}
                          className="font-semibold text-zinc-900 dark:text-zinc-100 text-sm hover:text-emerald-600 dark:hover:text-emerald-400 text-left transition-colors flex items-center gap-1.5 group"
                        >
                          <span>{inv.client}</span>
                          <Eye className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-emerald-600" />
                        </button>
                        <div className="flex items-center gap-2 mt-0.5 text-zinc-500 dark:text-zinc-400 text-[11px]">
                          <button
                            type="button"
                            onClick={() => onViewDetails(inv)}
                            className="font-mono hover:underline hover:text-emerald-600"
                          >
                            {inv.id}
                          </button>
                          {inv.email && (
                            <span className="inline-flex items-center gap-1" title={inv.email}>
                              <Mail className="w-3 h-3" />
                              <span className="max-w-[120px] truncate">{inv.email}</span>
                            </span>
                          )}
                          {inv.phone && (
                            <span className="inline-flex items-center gap-1" title={inv.phone}>
                              <Phone className="w-3 h-3" />
                              <span>{inv.phone}</span>
                            </span>
                          )}
                        </div>
                        {inv.items && inv.items.length > 0 && (
                          <div className="text-[11px] text-zinc-400 mt-1 truncate max-w-xs">
                            {inv.items.map((it) => it.desc).join(', ')}
                          </div>
                        )}
                      </td>

                      {/* Amount column */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="font-bold text-zinc-900 dark:text-zinc-100">
                          {formatCurrency(total, inv.currency)}
                        </div>
                        {inv.currency === 'NGN' && (
                          <div className="text-[11px] text-zinc-500">
                            approx. {formatUSD(inv.totalUSD || total / inv.rate)}
                          </div>
                        )}
                      </td>

                      {/* Due date column */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="text-zinc-800 dark:text-zinc-200 font-medium">
                          {inv.due}
                        </div>
                        {eff === 'Overdue' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-600 dark:text-rose-400">
                            <AlertTriangle className="w-3 h-3" />
                            {daysLate} {daysLate === 1 ? 'day' : 'days'} late
                          </span>
                        )}
                        {eff === 'Paid' && inv.paidDate && (
                          <span className="text-[11px] text-emerald-600 dark:text-emerald-400">
                            Paid on {inv.paidDate}
                          </span>
                        )}
                      </td>

                      {/* Status & Quick Action (Editable Unpaid/Paid buttons!) */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <StatusButton
                            invoice={inv}
                            onStatusChange={onStatusChange}
                            size="sm"
                          />
                        </div>
                        <div className="text-[10px] text-zinc-400 mt-1">
                          {inv.status === 'Paid'
                            ? 'Marked paid • Click Mark Unpaid to revert'
                            : inv.status === 'Sent'
                            ? eff === 'Overdue'
                              ? 'Overdue • Click Mark Paid when settled'
                              : 'Awaiting payment • Click Mark Paid'
                            : 'Draft invoice'}
                        </div>
                      </td>

                      {/* Actions column */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Send Reminder button: highlighted if overdue or unpaid */}
                          {inv.status !== 'Draft' && (
                            <button
                              type="button"
                              onClick={() => onOpenReminder(inv)}
                              title={
                                eff === 'Overdue'
                                  ? `Send overdue reminder (${daysLate} days late)`
                                  : 'Send friendly payment reminder'
                              }
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                                eff === 'Overdue'
                                  ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-xs animate-pulse hover:animate-none'
                                  : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                              }`}
                            >
                              <Bell className="w-3.5 h-3.5" />
                              <span>Remind</span>
                              {reminderCount > 0 && (
                                <span className="ml-0.5 text-[10px] px-1 rounded-full bg-black/20 text-white">
                                  {reminderCount}
                                </span>
                              )}
                            </button>
                          )}

                          {/* View details button */}
                          <button
                            type="button"
                            onClick={() => onViewDetails(inv)}
                            title="View Invoice Details & Toggle Paid/Unpaid"
                            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit button */}
                          <button
                            type="button"
                            onClick={() => onEditInvoice(inv)}
                            title="Edit Invoice Details"
                            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete button */}
                          <button
                            type="button"
                            onClick={() => onDeleteInvoice(inv.id)}
                            title="Delete Invoice"
                            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-400 flex items-center justify-center mx-auto mb-3">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100">
              No invoices found
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 max-w-sm mx-auto mt-1 mb-4">
              {searchQuery
                ? `No results match "${searchQuery}". Try clearing the search or filters.`
                : 'Turn WhatsApp conversations into professional invoices with automatic overdue follow-up.'}
            </p>
            <div className="flex items-center justify-center gap-2">
              <button
                onClick={onNewInvoice}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
              >
                + Create Invoice from Chat
              </button>
              {searchQuery && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setStatusFilter('all');
                  }}
                  className="px-4 py-2 text-xs font-semibold rounded-xl border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                >
                  Clear Filters
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
