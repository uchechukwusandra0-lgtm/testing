import { Invoice, UserSettings } from '../types/invoice';
import { DEFAULT_EXCHANGE_RATE, getTodayFormatted } from './currency';

const STORAGE_KEYS = {
  INVOICES: 'chat_invoice_list_v3',
  SETTINGS: 'chat_invoice_settings_v3',
};

export const DEFAULT_SETTINGS: UserSettings = {
  name: 'Alex Johnson',
  email: 'alex@creativestudio.dev',
  businessName: 'Apex Digital Studio',
  defaultCurrency: 'NGN',
  exchangeRateNGN: DEFAULT_EXCHANGE_RATE,
  paymentDetails: 'GTBank (Nigeria): 0123456789 (Alex Johnson)\nUSD Wire: Routing #021000021 / Account #987654321',
  paypalEmail: 'alex.payments@example.com',
  cadenceConfig: {
    day3Enabled: true,
    day7Enabled: true,
    day14Enabled: true,
    autoSendEnabled: true,
  },
};

// Calculate sample due dates relative to today
function offsetDays(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const INITIAL_SAMPLE_INVOICES: Invoice[] = [
  {
    id: 'INV-4821',
    client: 'Amaka Eze (UK)',
    email: 'amaka.creative@gmail.com',
    phone: '+447911123456',
    currency: 'NGN',
    rate: 1580,
    due: offsetDays(-9), // 9 days overdue
    items: [
      { id: '1', desc: 'Social Media Strategy & 3 Posts', amount: 45000 },
      { id: '2', desc: 'Animated Launch Banner', amount: 20000 },
    ],
    totalUSD: 41.14,
    status: 'Sent', // This is UNPAID and overdue!
    created: offsetDays(-16),
    reminders: [
      {
        id: 'rem-1',
        date: offsetDays(-4),
        channel: 'whatsapp',
        tone: 'friendly',
        recipient: 'Amaka Eze (UK)',
        notes: 'Sent via WhatsApp chat',
      },
    ],
  },
  {
    id: 'INV-3904',
    client: 'Chidi Okafor',
    email: 'chidi.designs@outlook.com',
    phone: '+2348031234567',
    currency: 'NGN',
    rate: 1580,
    due: offsetDays(-18), // 18 days overdue
    items: [{ id: '1', desc: 'Vector Brand Logo & Favicon', amount: 85000 }],
    totalUSD: 53.8,
    status: 'Sent', // UNPAID and heavily overdue!
    created: offsetDays(-25),
    reminders: [
      {
        id: 'rem-2',
        date: offsetDays(-10),
        channel: 'email',
        tone: 'friendly',
        recipient: 'chidi.designs@outlook.com',
      },
      {
        id: 'rem-3',
        date: offsetDays(-3),
        channel: 'whatsapp',
        tone: 'moderate',
        recipient: 'Chidi Okafor',
      },
    ],
  },
  {
    id: 'INV-7219',
    client: 'Kavita Patel',
    email: 'kavita@nordicventures.co',
    phone: '+14155552671',
    currency: 'USD',
    rate: 1580,
    due: offsetDays(4), // Due in 4 days
    items: [
      { id: '1', desc: 'UI/UX Mobile App Redesign', amount: 650 },
      { id: '2', desc: 'Figma Interactive Prototype', amount: 250 },
    ],
    totalUSD: 900,
    status: 'Sent', // Unpaid, but upcoming
    created: offsetDays(-3),
  },
  {
    id: 'INV-1882',
    client: 'David Miller',
    email: 'david@greenline-logistics.com',
    phone: '+12125550198',
    currency: 'USD',
    rate: 1580,
    due: offsetDays(-2),
    items: [{ id: '1', desc: 'WordPress Landing Page Speed Optimization', amount: 320 }],
    totalUSD: 320,
    status: 'Paid', // Paid invoice (user might test reverting to unpaid!)
    paidDate: offsetDays(-1),
    created: offsetDays(-10),
  },
  {
    id: 'INV-9023',
    client: 'Tunde Bakare',
    email: 'tunde@bakaremedia.ng',
    phone: '+2348029876543',
    currency: 'NGN',
    rate: 1580,
    due: offsetDays(1),
    items: [{ id: '1', desc: 'Copywriting & Email Sequence for Product Drop', amount: 35000 }],
    totalUSD: 22.15,
    status: 'Draft', // Draft
    created: getTodayFormatted(),
  },
  // Additional current month invoice for robust ratio testing
  {
    id: 'INV-1901',
    client: 'Grace Obi (Apex Health)',
    email: 'grace@apexhealth.ng',
    phone: '+2348035551212',
    currency: 'USD',
    rate: 1580,
    due: offsetDays(-5),
    items: [{ id: '1', desc: 'Brand Identity Guidelines', amount: 480 }],
    totalUSD: 480,
    status: 'Paid',
    paidDate: offsetDays(-3),
    created: offsetDays(-12),
  },
  // Historical invoices for monthly revenue growth line chart
  {
    id: 'INV-1055',
    client: 'Sora Digital Agency',
    email: 'billing@soradigital.io',
    phone: '+14155550144',
    currency: 'USD',
    rate: 1580,
    due: '2026-09-20',
    items: [{ id: '1', desc: 'Full Stack React Web App Development', amount: 1680 }],
    totalUSD: 1680,
    status: 'Paid',
    paidDate: '2026-09-18',
    created: '2026-09-05',
  },
  {
    id: 'INV-1044',
    client: 'Nexus Cloud Labs',
    email: 'accounts@nexuscloud.io',
    phone: '+12065550189',
    currency: 'USD',
    rate: 1580,
    due: '2026-08-15',
    items: [{ id: '1', desc: 'Design System & Component Library', amount: 1350 }],
    totalUSD: 1350,
    status: 'Paid',
    paidDate: '2026-08-14',
    created: '2026-08-01',
  },
  {
    id: 'INV-1033',
    client: 'Beacon Creative UK',
    email: 'finance@beaconcreative.co.uk',
    phone: '+442079460912',
    currency: 'USD',
    rate: 1580,
    due: '2026-07-22',
    items: [{ id: '1', desc: 'E-commerce Checkout UX Optimization', amount: 980 }],
    totalUSD: 980,
    status: 'Paid',
    paidDate: '2026-07-20',
    created: '2026-07-08',
  },
  {
    id: 'INV-1022',
    client: 'Horizon Media Partners',
    email: 'payouts@horizonmp.com',
    phone: '+13125550177',
    currency: 'USD',
    rate: 1580,
    due: '2026-06-18',
    items: [{ id: '1', desc: 'Brand Refresh & Pitch Deck Assets', amount: 720 }],
    totalUSD: 720,
    status: 'Paid',
    paidDate: '2026-06-17',
    created: '2026-06-03',
  },
  {
    id: 'INV-1011',
    client: 'Vanguard Ventures',
    email: 'info@vanguardventures.ng',
    phone: '+2348025550133',
    currency: 'NGN',
    rate: 1580,
    due: '2026-05-25',
    items: [{ id: '1', desc: 'Landing Page Strategy & Copy', amount: 750000 }],
    totalUSD: 474.68,
    status: 'Paid',
    paidDate: '2026-05-24',
    created: '2026-05-10',
  },
];

export function getSavedInvoices(): Invoice[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.INVOICES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(INITIAL_SAMPLE_INVOICES));
      return INITIAL_SAMPLE_INVOICES;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(INITIAL_SAMPLE_INVOICES));
      return INITIAL_SAMPLE_INVOICES;
    }
    return parsed;
  } catch (err) {
    console.error('Failed reading invoices from storage', err);
    return INITIAL_SAMPLE_INVOICES;
  }
}

export function saveInvoices(invoices: Invoice[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
  } catch (err) {
    console.error('Failed saving invoices to storage', err);
  }
}

export function getSavedSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed saving settings to storage', err);
  }
}

export function resetToSampleData(): Invoice[] {
  localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(INITIAL_SAMPLE_INVOICES));
  return INITIAL_SAMPLE_INVOICES;
}
