import { Invoice, UserSettings } from '../types/invoice';
import { formatCurrency, formatUSD, getDaysLate, getTotal } from './currency';

export type ReminderTone = 'friendly' | 'moderate' | 'firm' | 'custom';

export interface ReminderPreset {
  id: ReminderTone;
  label: string;
  badge: string;
  recommendedFor: string;
  subjectTemplate: string;
  bodyTemplate: string;
}

export const REMINDER_PRESETS: ReminderPreset[] = [
  {
    id: 'friendly',
    label: 'Friendly Nudge',
    badge: '1–7 days late',
    recommendedFor: 'Initial polite follow-up',
    subjectTemplate: 'Friendly Reminder: Invoice #{invoice_id} for {service_summary}',
    bodyTemplate: `Hi {client_name},

Hope you are doing well!

This is a gentle reminder that Invoice #{invoice_id} for {amount_original}{converted_usd_note} was due on {due_date} ({days_late_text}).

Could you please confirm when payment will be processed? If you've already sent it, please ignore this note.

{payment_info}

Thank you so much!
Best regards,
{sender_name}`,
  },
  {
    id: 'moderate',
    label: 'Professional Follow-Up',
    badge: '8–14 days late',
    recommendedFor: 'Second notice for pending payment',
    subjectTemplate: 'Payment Follow-Up: Invoice #{invoice_id} is overdue ({days_late} days)',
    bodyTemplate: `Hello {client_name},

I hope this message finds you well.

I am following up on Invoice #{invoice_id} ({amount_original}{converted_usd_note}), which was due on {due_date} and is now {days_late} days past due.

To ensure our accounts remain up to date, please arrange payment at your earliest convenience using the details below:

{payment_info}

If you have any questions or need a copy of the invoice, please let me know.

Thank you,
{sender_name}`,
  },
  {
    id: 'firm',
    label: 'Urgent / Final Notice',
    badge: '15+ days late',
    recommendedFor: 'Overdue accounts needing prompt settlement',
    subjectTemplate: 'URGENT: Overdue Invoice #{invoice_id} - Payment Required',
    bodyTemplate: `Dear {client_name},

This is an urgent notice regarding overdue Invoice #{invoice_id} in the amount of {amount_original}{converted_usd_note}.

The payment was due on {due_date} and is now {days_late} days overdue. Despite previous reminders, we have not yet received payment or confirmation.

Please process this payment immediately using the details below to prevent any disruption or suspension of ongoing work:

{payment_info}

Please reply with the payment confirmation or transfer receipt today.

Sincerely,
{sender_name}`,
  },
  {
    id: 'custom',
    label: 'Custom Message',
    badge: 'Any time',
    recommendedFor: 'Write or personalize your own reminder',
    subjectTemplate: 'Payment Reminder: Invoice #{invoice_id}',
    bodyTemplate: `Hi {client_name},

Quick reminder about Invoice #{invoice_id} ({amount_original}). It was due on {due_date}.

Please find the payment details below:
{payment_info}

Thanks!
{sender_name}`,
  },
];

export function getRecommendedTone(daysLate: number): ReminderTone {
  if (daysLate <= 7) return 'friendly';
  if (daysLate <= 14) return 'moderate';
  return 'firm';
}

export function compileReminderText(
  template: string,
  invoice: Invoice,
  settings?: Partial<UserSettings>
): string {
  const daysLate = getDaysLate(invoice);
  const total = getTotal(invoice);
  const formattedOrig = formatCurrency(total, invoice.currency);
  const convertedNote =
    invoice.currency === 'NGN'
      ? ` (approx. ${formatUSD(invoice.totalUSD || total / invoice.rate)})`
      : '';

  const serviceSummary =
    invoice.items && invoice.items.length > 0
      ? invoice.items.map((i) => i.desc).slice(0, 2).join(' + ')
      : 'Services';

  let paymentInfo = '';
  if (settings?.paypalEmail) {
    paymentInfo += `• PayPal: ${settings.paypalEmail}\n`;
  }
  if (settings?.paymentDetails) {
    paymentInfo += `• Payment Details:\n${settings.paymentDetails}\n`;
  }
  if (!paymentInfo.trim()) {
    paymentInfo = '• Payment link / Bank details: Please reply for bank transfer or PayPal details.\n';
  }

  const daysLateText = daysLate === 1 ? '1 day overdue' : `${daysLate} days overdue`;

  return template
    .replace(/{client_name}/g, invoice.client || 'Client')
    .replace(/{invoice_id}/g, invoice.id || 'INV-001')
    .replace(/{amount_original}/g, formattedOrig)
    .replace(/{converted_usd_note}/g, convertedNote)
    .replace(/{due_date}/g, invoice.due || 'as agreed')
    .replace(/{days_late}/g, String(daysLate))
    .replace(/{days_late_text}/g, daysLateText)
    .replace(/{service_summary}/g, serviceSummary)
    .replace(/{payment_info}/g, paymentInfo.trim())
    .replace(/{sender_name}/g, settings?.name || settings?.businessName || 'Your Name / Business');
}

export function buildWhatsAppUrl(phone: string | undefined, message: string): string {
  const cleanPhone = (phone || '').replace(/[^0-9]/g, '');
  const encodedText = encodeURIComponent(message);
  if (cleanPhone.length >= 7) {
    return `https://wa.me/${cleanPhone}?text=${encodedText}`;
  }
  // WhatsApp web share link if no specific phone number
  return `https://api.whatsapp.com/send?text=${encodedText}`;
}

export function buildMailtoUrl(email: string, subject: string, body: string): string {
  const cleanEmail = email ? email.trim() : '';
  const encodedSubject = encodeURIComponent(subject);
  const encodedBody = encodeURIComponent(body);
  return `mailto:${cleanEmail}?subject=${encodedSubject}&body=${encodedBody}`;
}
