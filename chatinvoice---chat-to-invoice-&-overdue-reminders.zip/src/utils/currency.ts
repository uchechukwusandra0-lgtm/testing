import { Invoice } from '../types/invoice';

export const DEFAULT_EXCHANGE_RATE = 1580; // NGN per USD

export function formatUSD(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount || 0);
}

export function formatNGN(amount: number): string {
  return new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount || 0);
}

export function formatCurrency(amount: number, currency: string): string {
  if (currency === 'NGN') return formatNGN(amount);
  if (currency === 'EUR') return `€${(amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  if (currency === 'GBP') return `£${(amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  return formatUSD(amount);
}

export function getTotal(invoice: Partial<Invoice>): number {
  if (!invoice.items || invoice.items.length === 0) return 0;
  return invoice.items.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
}

export function calculateUSD(invoice: Partial<Invoice>, defaultRate = DEFAULT_EXCHANGE_RATE): number {
  const total = getTotal(invoice);
  const rate = invoice.rate || defaultRate;
  if (invoice.currency === 'NGN') {
    return total / rate;
  }
  return total;
}

export function getTodayFormatted(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getEffectiveStatus(invoice: Invoice, todayStr = getTodayFormatted()): 'Draft' | 'Sent' | 'Overdue' | 'Paid' {
  if (invoice.status === 'Paid') return 'Paid';
  if (invoice.status === 'Draft') return 'Draft';
  // If invoice is 'Sent' (meaning Unpaid)
  if (invoice.due && invoice.due < todayStr) {
    return 'Overdue';
  }
  return 'Sent';
}

export function getDaysLate(invoice: Invoice, todayStr = getTodayFormatted()): number {
  if (!invoice.due || invoice.status === 'Paid') return 0;
  const today = new Date(todayStr);
  const dueDate = new Date(invoice.due);
  const diffTime = today.getTime() - dueDate.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}
