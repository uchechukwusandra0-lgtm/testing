import { InvoiceItem } from '../types/invoice';
import { getTodayFormatted } from './currency';

export interface ParsedChatResult {
  client: string;
  email: string;
  phone: string;
  currency: 'NGN' | 'USD' | null;
  due: string;
  items: InvoiceItem[];
}

export function parseDueDate(text: string): string {
  const d = new Date();
  const addDays = (n: number) => {
    const copy = new Date(d);
    copy.setDate(copy.getDate() + n);
    const year = copy.getFullYear();
    const month = String(copy.getMonth() + 1).padStart(2, '0');
    const day = String(copy.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  if (/tomorrow/i.test(text)) return addDays(1);
  if (/today|tonight/i.test(text)) return addDays(0);

  const inDaysMatch = text.match(/in\s+(\d+)\s+days?/i);
  if (inDaysMatch) return addDays(parseInt(inDaysMatch[1], 10));

  const daysOfWeek = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const dayMatch = text.match(/\b(sun|mon|tues?|wed(?:nes)?|thu(?:rs)?|fri|sat(?:ur)?)(?:day)?\b/i);
  if (dayMatch) {
    const prefix = dayMatch[1].slice(0, 3).toLowerCase();
    const targetIdx = daysOfWeek.indexOf(prefix);
    if (targetIdx !== -1) {
      const currentDay = d.getDay();
      let diff = targetIdx - currentDay;
      if (diff <= 0) diff += 7;
      return addDays(diff);
    }
  }

  // Default: in 7 days
  return addDays(7);
}

export function parseWhatsAppChat(text: string): ParsedChatResult {
  let client = '';
  let email = '';
  let phone = '';
  const items: InvoiceItem[] = [];
  let currency: 'NGN' | 'USD' | null = null;

  // Currency detection in whole text
  if (/₦|naira|ngn/i.test(text)) {
    currency = 'NGN';
  } else if (/\$|usd|dollar/i.test(text)) {
    currency = 'USD';
  }

  // Detect email if present
  const emailMatch = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  if (emailMatch) {
    email = emailMatch[0];
  }

  // Detect phone if present
  const phoneMatch = text.match(/(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
  if (phoneMatch) {
    phone = phoneMatch[0].trim();
  }

  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);

  for (const line of lines) {
    // Check WhatsApp pattern like "Amaka: ..." or "[12:30 PM] John Doe: ..."
    const match = line.match(/^(?:\[\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?\]\s*)?([^:]{1,40}):\s*(.*)$/i);
    const sender = match ? match[1].trim() : '';
    const msg = match ? match[2].trim() : line;

    // Skip me/you/self
    if (/^(me|you|i|myself)$/i.test(sender)) continue;

    if (sender && !client) {
      // Clean up bracketed text e.g. "Amaka (UK)" -> "Amaka (UK)"
      client = sender.replace(/^\[.*?\]\s*/, '').trim();
    }

    // Parse amounts in the message
    // Matches e.g. "₦45,000", "$500", "5k", "20,000", "5000"
    const regex = /(₦|\$|ngn|usd)?\s?(\d[\d,]*(?:\.\d+)?)\s?(k|m)?(?![a-z\d])/gi;
    let execResult: RegExpExecArray | null;
    let lastIndex = 0;

    while ((execResult = regex.exec(msg)) !== null) {
      const symbol = execResult[1];
      const rawNumber = execResult[2];
      const multiplier = execResult[3];

      let numVal = parseFloat(rawNumber.replace(/,/g, ''));
      if (multiplier) {
        if (/k/i.test(multiplier)) numVal *= 1000;
        if (/m/i.test(multiplier)) numVal *= 1000000;
      }

      // Ignore low standalone numbers that might just be quantities or dates unless accompanied by symbol or k
      if (!symbol && !multiplier && numVal < 50) {
        continue;
      }

      if (symbol) {
        if (/₦|ngn/i.test(symbol)) currency = 'NGN';
        if (/\$|usd/i.test(symbol)) currency = 'USD';
      }

      // Extract preceding text describing the service
      let descPart = msg.slice(lastIndex, execResult.index);
      descPart = descPart
        .replace(/[,.]?\s*(for|at|is|=|:|\bat\b)\s*$/i, '')
        .trim()
        .split(/\s+/)
        .slice(-4)
        .join(' ');

      descPart = descPart
        .replace(/^((and|the|a|do|that|can|you|hi|please|for)\s+)+/i, '')
        .replace(/^\d+\s+(?=\D)/, (m) => m)
        .trim();

      if (!descPart) {
        descPart = 'Professional Service';
      } else {
        descPart = descPart.charAt(0).toUpperCase() + descPart.slice(1);
      }

      items.push({
        id: `item-${Math.random().toString(36).slice(2, 9)}`,
        desc: descPart,
        amount: numVal,
      });

      lastIndex = regex.lastIndex;
    }
  }

  const due = parseDueDate(text);

  return {
    client: client || '',
    email,
    phone,
    currency,
    due,
    items,
  };
}
