import React, { useState, useEffect } from 'react';
import {
  Invoice,
  InvoiceStatus,
  ReminderLog,
  UserSettings,
} from './types/invoice';
import {
  getSavedInvoices,
  saveInvoices,
  getSavedSettings,
  saveSettings,
  resetToSampleData,
} from './utils/storage';
import { getEffectiveStatus, getTodayFormatted } from './utils/currency';
import { getPendingCadenceEmails } from './utils/cadenceEngine';

import { Header, NavTab } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { InvoiceList } from './components/InvoiceList';
import { OverdueHub } from './components/OverdueHub';
import { ChatExtractor } from './components/ChatExtractor';
import { WeeklySummary } from './components/WeeklySummary';
import { ReminderModal } from './components/ReminderModal';
import { InvoiceDetailModal } from './components/InvoiceDetailModal';
import { InvoiceEditor } from './components/InvoiceEditor';
import { AutomatedCadenceModal } from './components/AutomatedCadenceModal';
import { SettingsModal } from './components/SettingsModal';
import { Toast, ToastMessage } from './components/Toast';
import { Zap, Bell, CheckCircle2, Clock } from 'lucide-react';

export default function App() {
  const [invoices, setInvoices] = useState<Invoice[]>(() => getSavedInvoices());
  const [settings, setSettings] = useState<UserSettings>(() => getSavedSettings());
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');

  // Modal states
  const [activeReminderInvoice, setActiveReminderInvoice] = useState<Invoice | null>(null);
  const [activeDetailInvoice, setActiveDetailInvoice] = useState<Invoice | null>(null);
  const [activeEditInvoice, setActiveEditInvoice] = useState<Invoice | null>(null);
  const [isAutomatedCadenceOpen, setIsAutomatedCadenceOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Toast notifications (with Undo capabilities)
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (
    text: string,
    type: 'success' | 'error' | 'info' | 'undo' = 'success',
    actionLabel?: string,
    onAction?: () => void
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newToast: ToastMessage = { id, text, type, actionLabel, onAction };
    setToasts((prev) => [...prev, newToast]);

    // Auto dismiss after 4 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync to storage
  useEffect(() => {
    saveInvoices(invoices);
  }, [invoices]);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Keep activeDetailInvoice and activeReminderInvoice in sync if invoices change
  useEffect(() => {
    if (activeDetailInvoice) {
      const refreshed = invoices.find((i) => i.id === activeDetailInvoice.id);
      if (refreshed) setActiveDetailInvoice(refreshed);
    }
    if (activeReminderInvoice) {
      const refreshed = invoices.find((i) => i.id === activeReminderInvoice.id);
      if (refreshed) setActiveReminderInvoice(refreshed);
    }
  }, [invoices]);

  // Overdue count calculation
  const overdueCount = invoices.filter((i) => getEffectiveStatus(i) === 'Overdue').length;

  // Pending cadence count
  const pendingCadenceEmails = getPendingCadenceEmails(invoices, settings);

  /**
   * Status change handler with UNDO capability
   * Resolves: "Users should be able to edit unpaid and paid buttons incase someone mistakenly ticks an invoice as paid"
   */
  const handleStatusChange = (invoice: Invoice, newStatus: InvoiceStatus) => {
    const previousStatus = invoice.status;
    const previousPaidDate = invoice.paidDate;

    const updatedInvoices = invoices.map((inv) => {
      if (inv.id === invoice.id) {
        return {
          ...inv,
          status: newStatus,
          paidDate: newStatus === 'Paid' ? getTodayFormatted() : undefined,
        };
      }
      return inv;
    });

    setInvoices(updatedInvoices);

    const actionText =
      newStatus === 'Paid'
        ? `Invoice ${invoice.id} marked as Paid`
        : newStatus === 'Sent'
        ? `Invoice ${invoice.id} reverted to Unpaid (Sent)`
        : `Invoice ${invoice.id} set to Draft`;

    // Provide Undo button in toast!
    addToast(actionText, 'undo', 'Undo', () => {
      // Revert back
      setInvoices((prev) =>
        prev.map((inv) => {
          if (inv.id === invoice.id) {
            return {
              ...inv,
              status: previousStatus,
              paidDate: previousPaidDate,
            };
          }
          return inv;
        })
      );
      addToast(`Reverted ${invoice.id} back to ${previousStatus}`, 'info');
    });
  };

  const handleUpdateInvoice = (updated: Invoice) => {
    setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
    addToast(`Invoice ${updated.id} updated`, 'success');
  };

  const handleDeleteInvoice = (id: string) => {
    if (confirm(`Are you sure you want to delete invoice ${id}? This cannot be undone.`)) {
      setInvoices((prev) => prev.filter((inv) => inv.id !== id));
      if (activeDetailInvoice?.id === id) setActiveDetailInvoice(null);
      addToast(`Invoice ${id} deleted`, 'info');
    }
  };

  const handleSaveNewInvoice = (newInv: Invoice) => {
    setInvoices((prev) => [newInv, ...prev]);
    setCurrentTab('invoices');
    addToast(`Invoice ${newInv.id} created successfully for ${newInv.client}`, 'success');
  };

  const handleLogReminder = (
    invoiceId: string,
    log: Omit<ReminderLog, 'id' | 'date'>
  ) => {
    const now = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const newLogItem: ReminderLog = {
      ...log,
      id: `rem-${Date.now()}`,
      date: now,
    };

    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === invoiceId) {
          return {
            ...inv,
            reminders: [...(inv.reminders || []), newLogItem],
          };
        }
        return inv;
      })
    );

    addToast(`Reminder logged for ${log.recipient}`, 'success');
  };

  const handleUpdateClientContact = (invoiceId: string, phone: string, email: string) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === invoiceId) {
          return { ...inv, phone, email };
        }
        return inv;
      })
    );
    addToast('Client contact coordinates updated', 'success');
  };

  const handleResetData = () => {
    const fresh = resetToSampleData();
    setInvoices(fresh);
    addToast('Sample invoices and overdue records restored', 'info');
  };

  return (
    <div className="min-h-screen bg-zinc-100 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 flex flex-col font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Global Top Navbar */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          if (tab === 'settings') {
            setIsSettingsOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
        overdueCount={overdueCount}
        settings={settings}
        onResetData={handleResetData}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {/* Automated Cadence Reminder Banner */}
        {pendingCadenceEmails.length > 0 && currentTab !== 'new' && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-emerald-500/10 to-transparent border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-amber-900 dark:text-amber-200 flex items-center gap-2">
                  <span>Automated Overdue Cadence Engine</span>
                  <span className="px-2 py-0.2 rounded-full text-[10px] bg-amber-500 text-white font-extrabold">
                    {pendingCadenceEmails.length} Pending
                  </span>
                </div>
                <p className="text-xs text-amber-800/80 dark:text-amber-300/80 mt-0.5">
                  {pendingCadenceEmails.length} client{pendingCadenceEmails.length === 1 ? '' : 's'} reached their 3-day, 7-day, or 14-day overdue follow-up milestone.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsAutomatedCadenceOpen(true)}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-xs transition-all flex items-center justify-center gap-1.5 shrink-0"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Review & Dispatch Cadence Emails &rarr;</span>
            </button>
          </div>
        )}

        {/* Dynamic Tab Views */}
        {currentTab === 'dashboard' && (
          <Dashboard
            invoices={invoices}
            settings={settings}
            onOpenReminder={(inv) => setActiveReminderInvoice(inv)}
            onViewDetails={(inv) => setActiveDetailInvoice(inv)}
            onStatusChange={handleStatusChange}
            onNewInvoice={() => setCurrentTab('new')}
          />
        )}

        {currentTab === 'invoices' && (
          <InvoiceList
            invoices={invoices}
            settings={settings}
            onOpenReminder={(inv) => setActiveReminderInvoice(inv)}
            onViewDetails={(inv) => setActiveDetailInvoice(inv)}
            onEditInvoice={(inv) => setActiveEditInvoice(inv)}
            onDeleteInvoice={handleDeleteInvoice}
            onStatusChange={handleStatusChange}
            onNewInvoice={() => setCurrentTab('new')}
            onResetData={handleResetData}
          />
        )}

        {currentTab === 'overdue' && (
          <OverdueHub
            invoices={invoices}
            settings={settings}
            onOpenReminder={(inv) => setActiveReminderInvoice(inv)}
            onViewDetails={(inv) => setActiveDetailInvoice(inv)}
            onStatusChange={handleStatusChange}
            onNewInvoice={() => setCurrentTab('new')}
          />
        )}

        {currentTab === 'new' && (
          <ChatExtractor
            settings={settings}
            onSaveInvoice={handleSaveNewInvoice}
            onCancel={() => setCurrentTab('invoices')}
          />
        )}

        {currentTab === 'summary' && (
          <WeeklySummary
            invoices={invoices}
            settings={settings}
            onOpenReminder={(inv) => setActiveReminderInvoice(inv)}
          />
        )}
      </main>

      {/* Floating Overdue Reminder Modal */}
      {activeReminderInvoice && (
        <ReminderModal
          invoice={activeReminderInvoice}
          settings={settings}
          isOpen={true}
          onClose={() => setActiveReminderInvoice(null)}
          onLogReminder={handleLogReminder}
          onUpdateClientContact={handleUpdateClientContact}
        />
      )}

      {/* Full Invoice Details Modal with Paid/Unpaid Confirmation Step */}
      {activeDetailInvoice && (
        <InvoiceDetailModal
          invoice={activeDetailInvoice}
          settings={settings}
          isOpen={true}
          onClose={() => setActiveDetailInvoice(null)}
          onStatusChangeWithConfirmation={handleStatusChange}
          onOpenReminderModal={(inv) => {
            setActiveDetailInvoice(null);
            setActiveReminderInvoice(inv);
          }}
          onEditInvoice={(inv) => {
            setActiveDetailInvoice(null);
            setActiveEditInvoice(inv);
          }}
        />
      )}

      {/* Full Invoice Editor Modal */}
      {activeEditInvoice && (
        <InvoiceEditor
          invoice={activeEditInvoice}
          settings={settings}
          isOpen={true}
          onClose={() => setActiveEditInvoice(null)}
          onSave={handleUpdateInvoice}
        />
      )}

      {/* Automated Cadence Engine Modal (3d, 7d, 14d) */}
      {isAutomatedCadenceOpen && (
        <AutomatedCadenceModal
          invoices={invoices}
          settings={settings}
          isOpen={true}
          onClose={() => setIsAutomatedCadenceOpen(false)}
          onUpdateInvoice={handleUpdateInvoice}
          onUpdateSettings={(newSettings) => setSettings(newSettings)}
          onNotify={(msg) => addToast(msg, 'success')}
        />
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          isOpen={true}
          onClose={() => setIsSettingsOpen(false)}
          onSave={(newSettings) => {
            setSettings(newSettings);
            addToast('Settings & exchange rates updated', 'success');
          }}
          onResetData={handleResetData}
        />
      )}

      {/* Floating Toasts with Undo action */}
      <Toast toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
